//type
const TYPEXXX = '/type/xxx';

//action
export const actionXXX = (data) => ({
    type:TYPEXXX,
    payload:data
});

//reducer
const initState = {
  
};

export default (state=initState,action)=>{
    switch (action.type) {
        
        default:
            return state;
    }
}
