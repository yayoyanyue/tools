import React, {Component, Fragment} from 'react';

class ${NAME} extends Component {
    constructor(props) {
        super(props);
        this.state = {
        
        };
        [''].forEach((m) => {
            this[m] = this[m].bind(this);
        });
    }

    render() {
        return (
            <Fragment>
            <div className='${NAME}'>
              ${NAME}
            </div>
            </Fragment>
        )
    }
}

export default ${NAME};