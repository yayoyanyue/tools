/**
 * Created by yanyue on ${DATE} ${TIME} 
 */
const  ${NAME} = {
    namespaced: true,
    state: {
        
    },
    mutations: {
       
    },
    actions: {
      
    },
    getters: {
    
    }
};

export default  ${NAME} ;
