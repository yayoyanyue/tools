<template>
    <div class='${NAME}'>
        ${NAME}
    </div>
</template>

<script>
/**
 * Created by yanyue on ${DATE} ${TIME} 
 */

export default {
    name: "${NAME}",
    data(){
      return {
        
      }
    },
    methods:{
    
    }
}
</script>

<style lang='less' scoped>
.${NAME}{

}
</style>