<template>
    <div class='${NAME}'>
        ${NAME}
    </div>
</template>

<script lang="ts">
/**
 * Created by yanyue on ${DATE} ${TIME} 
 */

   import {Component, Vue, Provide} from 'vue-property-decorator';

    @Component({
        components: {}
    })

    export default class ${NAME} extends Vue {
    }

</script>

<style lang='scss' scoped>
.${NAME}{

}
</style>