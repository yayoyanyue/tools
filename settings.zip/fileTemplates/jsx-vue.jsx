export default {
  name: '${NAME}',
  data() {
    return {}
  },
  render() {
    return (
      <div class="${NAME}">
      
      </div>
    )
  }
}
